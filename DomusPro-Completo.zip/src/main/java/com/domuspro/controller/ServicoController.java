package com.domuspro.controller;

import com.domuspro.model.Servico;
import com.domuspro.repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ServicoController {

    @Autowired
    private ServicoRepository servicoRepository;

    @GetMapping("/servicos")
    public String listarServicos(Model model) {
        List<Servico> servicos = servicoRepository.findAll();
        model.addAttribute("servicos", servicos);
        return "servicos";
    }
}