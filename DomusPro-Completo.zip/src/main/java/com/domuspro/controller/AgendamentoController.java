package com.domuspro.controller;

import com.domuspro.model.Agendamento;
import com.domuspro.model.Servico;
import com.domuspro.model.Usuario;
import com.domuspro.repository.AgendamentoRepository;
import com.domuspro.repository.ServicoRepository;
import com.domuspro.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;

@Controller
public class AgendamentoController {

    @Autowired
    private AgendamentoRepository agendamentoRepository;

    @Autowired
    private ServicoRepository servicoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/agendar")
    public String agendarForm(Model model) {
        model.addAttribute("agendamento", new Agendamento());
        model.addAttribute("servicos", servicoRepository.findAll());
        return "agendamento";
    }

    @PostMapping("/agendar")
    public String agendar(@ModelAttribute Agendamento agendamento, Principal principal) {
        Usuario usuario = usuarioRepository.findByEmail(principal.getName()).orElseThrow();
        agendamento.setUsuario(usuario);
        agendamento.setStatus("PENDENTE");
        agendamento.setData(LocalDate.now().plusDays(1));
        agendamentoRepository.save(agendamento);
        return "redirect:/perfil";
    }
}