package com.domuspro.model;

import jakarta.persistence.*;

@Entity
@Table(name = "feedbacks")
public class Feedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int nota;
    private String comentario;

    @ManyToOne
    private Usuario usuario;

    @ManyToOne
    private Servico servico;

    // Getters e Setters
}