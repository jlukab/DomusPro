package com.domuspro.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String email;
    private String senha;
    private String tipo;

    @OneToMany(mappedBy = "usuario")
    private List<Agendamento> agendamentos;

    // Getters e Setters
}