package com.domuspro.model;

import jakarta.persistence.*;

@Entity
@Table(name = "empresa_info")
public class EmpresaInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private String descricao;

    // Getters e Setters
}