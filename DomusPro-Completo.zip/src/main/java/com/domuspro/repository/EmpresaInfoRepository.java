package com.domuspro.repository;

import com.domuspro.model.EmpresaInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpresaInfoRepository extends JpaRepository<EmpresaInfo, Long> {}